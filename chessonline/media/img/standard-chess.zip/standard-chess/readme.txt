Standard Chess Icons

Product page: http://www.standard-icons.com/stock-icons/standard-chess-icons.htm